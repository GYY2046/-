RateLimiters
============

[Token Bucket](http://en.wikipedia.org/wiki/Token_bucket)  and [Leaky Bucket](http://en.wikipedia.org/wiki/Leaky_bucket) implementations in .NET. These strategies can be used to rate limit requests in diverse web, backend or API calls scenarios.


This project is a .NET clone after this [Java implementation](https://github.com/sudohippie/throttle) by @sudohippie

## Build status [![Build status](https://ci.appveyor.com/api/projects/status/pagvorubf758v6nl)](https://ci.appveyor.com/project/robertmircea/ratelimiters)

This library is continuously integrated using [AppVeyor](http://www.appveyor.com/) service.
